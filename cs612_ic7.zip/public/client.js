"use strict";
(function () {
  window.addEventListener("load", init);
  function init() {
    document.getElementById("country_btn").addEventListener("click", requestCountry);
  }
  function checkStatus(response) {
    if (!response.ok) {
      throw Error("Error in request: " + response.statusText);
    }
    return response;
  }
  function requestCountry() {
    const contents = document.getElementById("country_code").value;
    fetch("country?code=" + contents)
      .then(checkStatus)
      .then(resp => resp.json())
      .then(resp => {
        document.getElementById("country_name").textContent = resp.name;
      })
      .catch(console.error);

    fetch("states?country=" + contents)
      .then(checkStatus)
      .then(resp => resp.json())
      .then(resp => {
        let table = document.querySelector("table");
        table.innerHTML = '';
        let data = Object.keys(resp[0]);
        let thead = table.createTHead();
        let row = thead.insertRow();
        for (let k of data) {
          let th = document.createElement("th");
          let text = document.createTextNode(k);
          th.appendChild(text);
          row.appendChild(th);
        }
        for (let element of resp) {
          let row = table.insertRow();
          for (let key in element) {
            let cell = row.insertCell();
            let text = document.createTextNode(element[key]);
            cell.appendChild(text);
          }
        }
      });
  }
})();

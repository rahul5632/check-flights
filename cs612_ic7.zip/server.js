"use strict";

const { Client } = require('pg');
const express = require('express');
const app = express();
app.use(express.static("public"));
const PORT = 8000;
app.listen(PORT);

const clientConfig = {
  // WRITE CODE HERE
};

app.get('/country', async function (req, res) {
  // WRITE CODE HERE
});

app.get('/states', async function (req, res) {
  // WRITE CODE HERE
});
